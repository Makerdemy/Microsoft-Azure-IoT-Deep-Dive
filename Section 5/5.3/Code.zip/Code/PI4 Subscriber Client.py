from azure.servicebus import ServiceBusClient
import os


CONNECTION_STR = ''
TOPIC_NAME1 = "downstreamdevice1/temperature"
TOPIC_NAME2 = "downstreamdevice1/humidity"
SUBSCRIPTION_NAME1 = "downstreamdevice1subscription"

TOPIC_NAME3 = "downstreamdevice2/temperature"
TOPIC_NAME4 = "downstreamdevice2/humidity"
SUBSCRIPTION_NAME2 = "downstreamdevice2subscription"

servicebus_client = ServiceBusClient.from_connection_string(conn_str=CONNECTION_STR)
with servicebus_client:
    receiver = servicebus_client.get_subscription_receiver(
        topic_name=TOPIC_NAME1,
        subscription_name=SUBSCRIPTION_NAME1
    )
    with receiver:
        received_msgs = receiver.receive_messages(max_message_count=100, max_wait_time=5)
        for msg in received_msgs:
            # print(received_msgs)
            print(str(msg))
            receiver.complete_message(msg)
			
	receiver = servicebus_client.get_subscription_receiver(
    topic_name=TOPIC_NAME2,
    subscription_name=SUBSCRIPTION_NAME1
    )
    with receiver:
        received_msgs = receiver.receive_messages(max_message_count=100, max_wait_time=5)
        for msg in received_msgs:
            # print(received_msgs)
            print(str(msg))
            receiver.complete_message(msg)
			
	receiver = servicebus_client.get_subscription_receiver(
        topic_name=TOPIC_NAME3,
        subscription_name=SUBSCRIPTION_NAME2
    )
    with receiver:
        received_msgs = receiver.receive_messages(max_message_count=100, max_wait_time=5)
        for msg in received_msgs:
            # print(received_msgs)
            print(str(msg))
            receiver.complete_message(msg)
			
	receiver = servicebus_client.get_subscription_receiver(
    topic_name=TOPIC_NAME4,
    subscription_name=SUBSCRIPTION_NAME2
    )
    with receiver:
        received_msgs = receiver.receive_messages(max_message_count=100, max_wait_time=5)
        for msg in received_msgs:
            # print(received_msgs)
            print(str(msg))
            receiver.complete_message(msg)

print("Receive is done.")